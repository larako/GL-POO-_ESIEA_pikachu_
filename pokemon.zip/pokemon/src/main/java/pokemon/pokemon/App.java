package pokemon.pokemon;


public class App 
{
    public static void main( String[] args )
    {
    	Pokemon poke = new Pokemon(1);
    	System.out.println(poke);
    	
    }
}
