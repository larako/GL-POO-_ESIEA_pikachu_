package pokemon.pokemon;

import java.util.ArrayList;

public class Attack {
	
	private String name;
	private String type;
	private int value;
	private int number;
	
	public Attack(int id) {
		ArrayList<String> info = SQLPokemon.getAttackInfo(id);
		this.name = info.get(0);
		this.type = info.get(1);
		this.value = Integer.parseInt(info.get(2));
		this.number = Integer.parseInt(info.get(3));
	}
	
	public String toString() {
		return "{name : " + this.name + ", type : " + this.type
				+ ", value : " + this.value + ", value : " + this.value
				+ " number: " + this.number + " }";
	}
}
